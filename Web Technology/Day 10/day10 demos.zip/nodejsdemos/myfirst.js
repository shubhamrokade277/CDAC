console.log("log message")
console.warn("warning message")
console.error("error message")