const m3=require("./module3")
m3.function1();
m3.function3();
console.log(m3.user.uname);