var m1=require('./module1')
var ans=m1.addition(5,4)
console.log("addition : ",ans);
console.log("Factorial : ",m1.factorial(5));
