const m2=require('./module2')
console.log("combination: ",m2.combination(6,4))
